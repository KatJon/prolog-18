title('My prolog blog').
author('Katjon').

post('Post1', '12.02.12', 'Much post. Such wow.').
post('Post2', '10.02.09', 'Next post').